/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package registrationlogin;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_lab
 */
public class LoginTest {

    @Test
    public void testAuthenticateSuccess() {
        User user = new User("test_u", "Password1!", "John", "Doe", "+27123456789");
        Login login = new Login();

        boolean result = login.authenticate(user, "test_u", "Password1!");
        assertTrue("Authentication should succeed with correct credentials", result);
    }

    @Test
    public void testAuthenticateFailWrongUsername() {
        User user = new User("test_u", "Password1!", "John", "Doe", "+27123456789");
        Login login = new Login();

        boolean result = login.authenticate(user, "wrong_u", "Password1!");
        assertFalse("Authentication should fail with wrong username", result);
    }

    @Test
    public void testAuthenticateFailWrongPassword() {
        User user = new User("test_u", "Password1!", "John", "Doe", "+27123456789");
        Login login = new Login();

        boolean result = login.authenticate(user, "test_u", "WrongPass!");
        assertFalse("Authentication should fail with wrong password", result);
    }

    @Test
    public void testGetLoginStatusSuccess() {
        User user = new User("test_u", "Password1!", "John", "Doe", "+27123456789");
        Login login = new Login();

        String status = login.getLoginStatus(user, true);
        assertEquals("Welcome John, Doe it is great to see you again.", status);
    }

    @Test
    public void testGetLoginStatusFail() {
        User user = new User("test_u", "Password1!", "John", "Doe", "+27123456789");
        Login login = new Login();

        String status = login.getLoginStatus(user, false);
        assertEquals("Username or password incorrect, please try again.", status);
    }
}