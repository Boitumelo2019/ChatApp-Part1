/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package registrationlogin;

import javax.swing.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class MainGUITest {

    private MainGUI mainGUI;

    // Fields to simulate user input
    private String[] simulatedInputs;
    private int inputIndex;

    @BeforeEach
    public void setUp() throws Exception {
        // Reset index before each test
        inputIndex = 0;

        // Create real instance
        mainGUI = new MainGUI();

        // Inject real Registration and Login
        Field registrationField = MainGUI.class.getDeclaredField("registration");
        registrationField.setAccessible(true);
        registrationField.set(mainGUI, new Registration());

        Field loginField = MainGUI.class.getDeclaredField("login");
        loginField.setAccessible(true);
        loginField.set(mainGUI, new Login());

        // Override JOptionPane to simulate input/output
        overrideJOptionPane();
    }

    private void overrideJOptionPane() {
        // Override showInputDialog to return predefined inputs
        UIManager.put("OptionPane.showInputDialog", new JOptionPane() {
            @Override
            public String showInputDialog(Object message) {
                return simulatedInputs[inputIndex++];
            }
        });

        // Override showMessageDialog to print (can be removed or logged)
        UIManager.put("OptionPane.showMessageDialog", new JOptionPane() {
            @Override
            public void showMessageDialog(java.awt.Component parentComponent, Object message) {
                System.out.println("Message Dialog: " + message);
            }
        });
    }

    @Test
    public void testRegisterUserSuccessfully() throws Exception {
        // Set simulated inputs in expected order
        simulatedInputs = new String[]{
                "user_name",           // Username
                "Password123!",        // Password
                "+27123456789",        // Cell number
                "John",                // First name
                "Doe"                  // Last name
        };

        // Click the register button
        mainGUI.btnRegister.doClick();

        // Check that user was created
        Field userField = MainGUI.class.getDeclaredField("user");
        userField.setAccessible(true);
        User user = (User) userField.get(mainGUI);

        assertNotNull(user);
        assertEquals("user_name", user.getUsername());
        assertEquals("Password123!", user.getPassword());
        assertEquals("+27123456789", user.getCellPhoneNumber());
        assertEquals("John", user.getFirstName());
        assertEquals("Doe", user.getLastName());
    }

    @Test
    public void testLoginSuccess() throws Exception {
        // First register a user manually
        User testUser = new User("user_name", "Password123!", "John", "Doe", "+27123456789");

        Field userField = MainGUI.class.getDeclaredField("user");
        userField.setAccessible(true);
        userField.set(mainGUI, testUser);

        simulatedInputs = new String[]{
                "user_name",          // Username input
                "Password123!"        // Password input
        };

        // Click the login button
        mainGUI.btnLogin.doClick();

        // No exception = success
    }

    @Test
    public void testLoginFailure() throws Exception {
        // Register a user manually
        User testUser = new User("user_name", "Password123!", "John", "Doe", "+27123456789");

        Field userField = MainGUI.class.getDeclaredField("user");
        userField.setAccessible(true);
        userField.set(mainGUI, testUser);

        simulatedInputs = new String[]{
                "user_name",      // Correct username
                "wrongPass!"      // Wrong password
        };

        // Click login
        mainGUI.btnLogin.doClick();

        // No exception = handled correctly
    }

    @Test
    public void testLoginWithoutRegisteredUser() {
        simulatedInputs = new String[]{
                "anyuser", "anypass"
        };

        // Ensure no user registered
        mainGUI.user = null;

        // Click login
        mainGUI.btnLogin.doClick();

        // Should print "No user registered yet!" in dialog
    }
}