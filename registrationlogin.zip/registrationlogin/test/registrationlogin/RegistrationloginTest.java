
package registrationlogin;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RegistrationTest {

    @Test
    void testValidRegistration() {
        Registration registration = new Registration();

        // Test valid username
        String username = "user123";
        assertEquals("Username successfully captured.", 
                     registration.validateUsername(username));

        // Test valid password
        String password = "Pass@123";
        assertEquals("Password successfully captured.", 
                     registration.validatePassword(password));

        // Test valid phone number
        String phone = "+27123456789";
        assertEquals("Cell phone number successfully added.", 
                     registration.validateCellPhone(phone));

        // Test names
        String firstName = "John";
        String lastName = "Doe";

        // Register user
        User user = registration.registerUser(username, password, firstName, lastName, phone);

        assertNotNull(user, "User should be created");
        assertEquals("user123", user.getUsername());
        assertEquals("Pass@123", user.getPassword());
        assertEquals("John", user.getFirstName());
        assertEquals("Doe", user.getLastName());
        assertEquals("+27123456789", user.getCellPhoneNumber());
    }
}
