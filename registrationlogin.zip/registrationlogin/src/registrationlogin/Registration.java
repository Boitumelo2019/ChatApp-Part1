/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registrationlogin;

/**
 *
 * @author RC_Student_lab
 */
import java.util.regex.Pattern;

public class Registration {

    public String validateUsername(String username) {
        if (username.contains("_") && username.length() <= 10) {
            return "Username successfully captured.";
        }
        return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
    }

    public String validatePassword(String password) {
        boolean lengthOK = password.length() >= 10;
        boolean hasUpper = Pattern.compile("[A-Z]").matcher(password).find();
        boolean hasNumber = Pattern.compile("[0-9]").matcher(password).find();
        boolean hasSpecial = Pattern.compile("[^A-Za-z0-9]").matcher(password).find();

        if (lengthOK && hasUpper && hasNumber && hasSpecial) {
            return "Password successfully captured.";
        }
        return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
    }

    public String validateCellPhone(String cellPhoneNumber) {
        String regex = "^\\+[0-9]{1,3}[0-9]{7,10}$";
        if (Pattern.matches(regex, cellPhoneNumber)) {
            return "Cell phone number successfully added.";
        }
        return "Cell phone number incorrectly formatted or does not contain international code.";
    }

    public User registerUser(String username, String password, String firstName, String lastName, String cellPhoneNumber) {
        return new User(username, password, firstName, lastName, cellPhoneNumber);
    }
}
    

